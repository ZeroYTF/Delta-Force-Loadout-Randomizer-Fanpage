document.getElementById("randomizer").innerText =
  "Aquí aparecerán tus operadores, armas, casco y chaleco al azar :)";